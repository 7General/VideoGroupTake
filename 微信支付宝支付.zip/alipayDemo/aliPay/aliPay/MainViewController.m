//
//  MainViewController.m
//  aliPay
//
//  Created by admin on 17/4/13.
//  Copyright © 2017年 admin. All rights reserved.
//

#import "MainViewController.h"

#import <AlipaySDK/AlipaySDK.h>
#import "Order.h"
#import "RSADataSigner.h"


#import "RSAEncryptor.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.backgroundColor = [UIColor redColor];
    btn.frame = CGRectMake(100, 100, 100, 100);
    [btn addTarget:self action:@selector(aliPayClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

-(void)aliPayClick {
    //将商品信息赋予AlixPayOrder的成员变量
    Order* order = [Order new];
    // NOTE: app_id设置
    order.app_id = @"2016041801307689";
    // NOTE: 支付接口名称
    order.method = @"alipay.trade.app.pay";
    // NOTE: 参数编码格式
    order.charset = @"utf-8";
    // NOTE: 当前时间点
    NSDateFormatter* formatter = [NSDateFormatter new];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    order.timestamp = [formatter stringFromDate:[NSDate date]];
    // NOTE: 商品数据
    order.biz_content = [BizContent new];
    order.biz_content.body = @"我是测试数据";
    order.biz_content.seller_id = @"2088221671417221";
    order.biz_content.subject = @"洲哥打赏";
    order.biz_content.out_trade_no = [self generateTradeNO]; //订单ID（由商家自行制定）
    order.biz_content.timeout_express = @"30m"; //超时时间设置
    order.biz_content.total_amount = [NSString stringWithFormat:@"%.2f", 0.01]; //商品价格
    //将商品信息拼接成字符串
    NSString *orderInfo = [order orderInfoEncoded:NO];
    NSString *orderInfoEncoded = [order orderInfoEncoded:YES];
    NSString *rsa2PrivateKey = @"MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCR1WltlqBAMX8gOTciuCfkUwgTZ+RMgf6VEhJ0fgHW+inH2ltKcn0nJfQMhykCmZe+38T2PoKDVwqXMaXXuLgN4OzN6epfaKYVBih2+dHu0c86A4Qj+0Y3n8NdHP4azQcbq5XKhKqTCrxUwdKYfoZbv8xI6FoBZNQkyNEeig4o+wbD+5f72p8Bb9d4g2I+wltT0mF56LKJTnpWW4NJ45vR6ZB/WlEZYyhEtH8m1xpvg1rUsSpceDXilAZsioGg7sU+8BMYSlvkRgVfUjgSOKe7R5pEKFDVxzVSB4n2jCXvk8HO6NvssJAK4RtVQ/vIsRsratOVHaD6JivkzAgF0tX5AgMBAAECggEAOVAB6wuzVwccyvExdfeh1d274sSFuHuuLa+4iQeseWw/V0e9cPilruj/jJzhxR/Pvzf6FDxk1nEyvFDKuIjj7LBk4Ff5wB1EiCavaHKtyomyQz52hB2QbvPet41ZX/cLwBgi+kBBOSCS+0xhE4VGEHDEPDL0jG+v3/T8GmBvSDMmBi+B/89nlnKCszxGZZwbW2M2Pr/M3ccmCfW6uL/mpfy1CQk1YZbZ6VYaQwys1Ne8ecDomONN31P0nDI+YmFWLL2AzEyNna2JaBYb5KiDWx9r1kxCcN1AB5ebLyWM/9EVFAl8WGAFeq2uRj7Z3sO6ZTxNWbOj+idm04UXfFfIAQKBgQDehKa9lpZLqYx2QemNgdJATAwIxTDW1k7k0KnRvcPlxkSCEjPqLLBKsMSB9v1LpzEk9QYW6ItOoofP4h1nlXrzeylIguYncfqNnBTuPHGczF/a+wVFVdaYbQkCYbeE5GUGbIuN3oSEJnHhSUWteXyciSwutlnRiOTOJSefRKppuQKBgQCnxuPcHKfD/5DAdJfoCqOufy50rQZN0/UXAIw8KGzY2r/Ig9RRbXi+pP5OR/6LiX+Pl5LhQr7+1xGzQltYGbA+4QqaTL2Z2KO9NAlxzcg8PIZFh8tK0plqUHaH1RJfEnABWMHjXewjKdwdGpzwJaRw3jZZRVR41Q2r4hzsvGTuQQKBgBlTWbLsR7DW3EC9YbqUUvy0aw44e0WIYLRUN2/CvGATf8qaDcSST4JAuizckpmgrsw5AvdqgihyASkc4CHg9nxtwRYap91HcK/bWtp+kKO68xH2TfRFP8ZbapIV0xBR+lmP0xZThBuSUJXGhCKpWBBs4FV0taZOgVQhEHBlHUwpAoGBAKB1MPsUVMa4puHJIHcFpeF/NRjVWdAZRK+JEJWAPAlxvDWzDt4Jio8aETUg2aruB5d26TySr0PewMjmT6IEf3DDnXZQqox2irKrD9VNb5FceTYKVzzqCVuKNLJX70gJxCEll9kxvGMs55zWFP3/ojNn8iaSjeU6LecTS4KF8ymBAoGBALqjSdRiOKQsIWHLvVTZOLy2i+TEEWBH2CbV4famrQJnldYmioZIF/gccHQm2nPvamrSOPoG1xZ8pEWzOT4PrKJBkD+NUNIIPy+gm+oJbE2B3l3aLlUZv+amcc5Bo2kka/sMGiC5rOMrRAJmB7bTo2rGf2iCYkQ9kVOLxPj45jY8";
        NSString *signedString = nil;
    RSADataSigner* signer = [[RSADataSigner alloc] initWithPrivateKey:rsa2PrivateKey];
    signedString = [signer signString:orderInfo withRSA2:NO];
    
    

    // NOTE: 如果加签成功，则继续执行支po付
    if (signedString != nil) {
        NSString * newStr = [NSString stringWithFormat:@"%@&sign=%@",orderInfoEncoded,signedString];
        NSString *appScheme = @"alisdkdemo";
        [[AlipaySDK defaultService] payOrder:newStr fromScheme:appScheme callback:^(NSDictionary *resultDic) {
            NSLog(@"reslut = %@",resultDic);
        }];
    }
    
}



#pragma mark - 生产订单号
- (NSString *)generateTradeNO
{
    static int kNumber = 15;
    
    NSString *sourceStr = @"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    NSMutableString *resultStr = [[NSMutableString alloc] init];
    srand((unsigned)time(0));
    for (int i = 0; i < kNumber; i++)
    {
        unsigned index = rand() % [sourceStr length];
        NSString *oneStr = [sourceStr substringWithRange:NSMakeRange(index, 1)];
        [resultStr appendString:oneStr];
    }
    return resultStr;
}

@end
