//
//  ViewController.m
//  WxPayDemo
//
//  Created by 众网合一 on 16/6/14.
//  Copyright © 2016年 GdZwhy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    //发起微信支付
    [MXWechatPayHandler jumpToWxPay];
//    [self singFunc];
}

-(void)singFunc {
    // 签名加密
    MXWechatSignAdaptor *md5 = [[MXWechatSignAdaptor alloc] init];
    
    /*
     appid = wx7d3568d7b68a1519;
     mchId = 1327167401;
     noncestr = h73E6vxKuuqKQAW9;
     "prepay_id" = wx2017041418362716ba23d2490766131685;
     "return_code" = SUCCESS;
     "return_msg" = OK;
     sign = 0923C4A305876871184BB1307A1E7E2F;
                F380E0596087FAAE93D59ABE12CB9D67
     timestamp = 1492166134;
     */
    NSString * appid = @"wx7d3568d7b68a1519";
    NSString * mchId = @"1327167401";
    NSString * noncestr = @"h73E6vxKuuqKQAW9";
    NSString * prepay_id = @"wx2017041418362716ba23d2490766131685";
    NSString * timestamp = @"1492166134";
    
    NSString * sign = [md5 createMD5SingForPay:appid
                                partnerid:mchId
                                 prepayid:prepay_id
                                  package:@"Sign=WXPay"
                                 noncestr:noncestr
                                timestamp:[timestamp intValue]];
     NSLog(@"-----%@",sign);
}



@end
