//
//  SDPayHandle.m
//  weChatPay
//
//  Created by admin on 17/4/10.
//  Copyright © 2017年 admin. All rights reserved.
//

#import "SDPayHandle.h"
#import "NSData+EncryptAndDecrypt.h"


@implementation SDPayHandle

+ (instancetype)shareManager
{
    static dispatch_once_t onceToken;
    static SDPayHandle *payHandle = nil;
    dispatch_once(&onceToken, ^{
        payHandle = [[SDPayHandle alloc] init];
    });
    return payHandle;
}
+ (NSString *)lpj_wxPay:(NSDictionary *)infoDict
{
    
    /*
     WxJson =         {
     appid = wx7d3568d7b68a1519;
     mchId = 1327167401;
     noncestr = HnsGrHVHX5NeAId4;
     "prepay_id" = wx20170414161640496a8923b10643348539;
     "return_code" = SUCCESS;
     "return_msg" = OK;
     sign = BC4E70BB7F7A532224975075F8E5BA09;
     timestamp = 1492157746;
     };
     */
    
    
    /*
     "__name" = xml;
     appid = wxbff3f84cc71554c1;
     "mch_id" = 1380919002;
     "nonce_str" = kLA343NKrV6TKNmc;
     "prepay_id" = wx2017041416233791540feebc0563170642;
     "result_code" = SUCCESS;
     "return_code" = SUCCESS;
     "return_msg" = OK;
     sign = 376196D006F6E97E58BDE8D7AED14AE9;
     "trade_type" = APP
     */
    
    /*
     WxJson =         {
     appid = wx7d3568d7b68a1519;
     mchId = 1327167401;
     noncestr = 7RQJn4KDv0Eudu0u;
     "prepay_id" = wx20170414162756514877652e0760295479;
     "return_code" = SUCCESS;
     "return_msg" = OK;
     sign = AFAFFA2EF6437753C19BF261724D1E22;
     timestamp = 1492158422;
     };
     */
    
    
    //调起微信支付
    PayReq* req    = [[PayReq alloc] init];
    req.openID = @"wxbff3f84cc71554c1";
    req.partnerId     = @"1380919002";
    req.prepayId      = @"wx2017041417321108fd9e3d2d0236362642";
    req.nonceStr            = @"bfFMGCe2JfgVW2Jj";
    req.timeStamp           = 1492162490;
    req.package             = @"Sign=WXPay";
    req.sign                = @"D10B396B7E954A59C74EF5071D50688B";
    
    BOOL result = [WXApi sendReq:req];

    NSLog(@"-=-=-=-=- %d", result);
    
    return @"";
}


#pragma mark - WXApiDelegate

- (void)onResp:(BaseResp *)resp
{
    if ([resp isKindOfClass:[PayResp class]]) {
        switch (resp.errCode) {
            case WXSuccess:{
                NSLog(@"支付成功");
                
            }
                break;
                
            default:
                NSLog(@"错误, retcode = %d, retStr = %@", resp.errCode,resp.errStr);
                break;
        }
    }
}
@end
