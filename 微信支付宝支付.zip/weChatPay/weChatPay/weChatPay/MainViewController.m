//
//  MainViewController.m
//  weChatPay
//
//  Created by admin on 17/4/10.
//  Copyright © 2017年 admin. All rights reserved.
//

#import "MainViewController.h"
#import "SDPayHandle.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor lightTextColor];
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(weChatPay) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}
-(void)weChatPay {
//    NSLog(@"---");
    [SDPayHandle lpj_wxPay:nil];
//    [[SDPayHandle alloc] POSTNet];
//    [[SDPayHandle alloc] GETNet];
//    [[SDPayHandle alloc] test];
}


@end
