//
//  SDPayHandle.h
//  weChatPay
//
//  Created by admin on 17/4/10.
//  Copyright © 2017年 admin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WXApi.h"

@interface SDPayHandle : NSObject<WXApiDelegate>

+ (instancetype)shareManager;

// 微信 支付接口
+ (NSString *)lpj_wxPay:(NSDictionary *)infoDict;

-(void)POSTNet;
-(void)GETNet;
-(NSString *)test;
@end
